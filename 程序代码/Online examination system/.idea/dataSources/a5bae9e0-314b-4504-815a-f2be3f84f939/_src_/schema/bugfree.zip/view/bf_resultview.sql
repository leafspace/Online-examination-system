CREATE VIEW bugfree.bf_resultview AS
  SELECT
    `bugfree`.`bf_result_info`.`id`                                                               AS `id`,
    `bugfree`.`bf_result_info`.`created_at`                                                       AS `created_at`,
    `bugfree`.`bf_result_info`.`created_by`                                                       AS `created_by`,
    `bugfree`.`bf_result_info`.`updated_at`                                                       AS `updated_at`,
    `bugfree`.`bf_result_info`.`updated_by`                                                       AS `updated_by`,
    `bugfree`.`bf_result_info`.`result_status`                                                    AS `result_status`,
    `bugfree`.`bf_result_info`.`assign_to`                                                        AS `assign_to`,
    `bugfree`.`bf_result_info`.`result_value`                                                     AS `result_value`,
    `bugfree`.`bf_result_info`.`mail_to`                                                          AS `mail_to`,
    `bugfree`.`bf_result_info`.`result_step`                                                      AS `result_step`,
    `bugfree`.`bf_result_info`.`lock_version`                                                     AS `lock_version`,
    `bugfree`.`bf_result_info`.`related_bug`                                                      AS `related_bug`,
    `bugfree`.`bf_result_info`.`productmodule_id`                                                 AS `productmodule_id`,
    `bugfree`.`bf_result_info`.`modified_by`                                                      AS `modified_by`,
    `bugfree`.`bf_result_info`.`title`                                                            AS `title`,
    `bugfree`.`bf_result_info`.`related_case_id`                                                  AS `related_case_id`,
    `bugfree`.`bf_result_info`.`product_id`                                                       AS `product_id`,
    `bugfree`.`bf_product`.`name`                                                                 AS `product_name`,
    concat_ws('/', `bugfree`.`bf_product`.`name`, `bugfree`.`bf_product_module`.`full_path_name`) AS `module_name`,
    `uc`.`realname`                                                                               AS `created_by_name`,
    `uu`.`realname`                                                                               AS `updated_by_name`,
    `ua`.`realname`                                                                               AS `assign_to_name`
  FROM (((((`bugfree`.`bf_result_info`
    LEFT JOIN `bugfree`.`bf_test_user` `uc` ON ((`bugfree`.`bf_result_info`.`created_by` = `uc`.`id`))) LEFT JOIN
    `bugfree`.`bf_test_user` `uu` ON ((`bugfree`.`bf_result_info`.`updated_by` = `uu`.`id`))) LEFT JOIN
    `bugfree`.`bf_test_user` `ua` ON ((`bugfree`.`bf_result_info`.`assign_to` = `ua`.`id`))) LEFT JOIN
    `bugfree`.`bf_product` ON ((`bugfree`.`bf_result_info`.`product_id` = `bugfree`.`bf_product`.`id`))) LEFT JOIN
    `bugfree`.`bf_product_module`
      ON ((`bugfree`.`bf_result_info`.`productmodule_id` = `bugfree`.`bf_product_module`.`id`)));
