CREATE VIEW bugfree.bf_bugview AS
  SELECT
    `bugfree`.`bf_bug_info`.`id`                                                                  AS `id`,
    `bugfree`.`bf_bug_info`.`created_at`                                                          AS `created_at`,
    `bugfree`.`bf_bug_info`.`created_by`                                                          AS `created_by`,
    `bugfree`.`bf_bug_info`.`updated_at`                                                          AS `updated_at`,
    `bugfree`.`bf_bug_info`.`updated_by`                                                          AS `updated_by`,
    `bugfree`.`bf_bug_info`.`bug_status`                                                          AS `bug_status`,
    `bugfree`.`bf_bug_info`.`assign_to`                                                           AS `assign_to`,
    `bugfree`.`bf_bug_info`.`title`                                                               AS `title`,
    `bugfree`.`bf_bug_info`.`mail_to`                                                             AS `mail_to`,
    `bugfree`.`bf_bug_info`.`repeat_step`                                                         AS `repeat_step`,
    `bugfree`.`bf_bug_info`.`lock_version`                                                        AS `lock_version`,
    `bugfree`.`bf_bug_info`.`resolved_at`                                                         AS `resolved_at`,
    `bugfree`.`bf_bug_info`.`resolved_by`                                                         AS `resolved_by`,
    `bugfree`.`bf_bug_info`.`closed_at`                                                           AS `closed_at`,
    `bugfree`.`bf_bug_info`.`closed_by`                                                           AS `closed_by`,
    `bugfree`.`bf_bug_info`.`related_bug`                                                         AS `related_bug`,
    `bugfree`.`bf_bug_info`.`related_case`                                                        AS `related_case`,
    `bugfree`.`bf_bug_info`.`related_result`                                                      AS `related_result`,
    `bugfree`.`bf_bug_info`.`productmodule_id`                                                    AS `productmodule_id`,
    `bugfree`.`bf_bug_info`.`modified_by`                                                         AS `modified_by`,
    `bugfree`.`bf_bug_info`.`solution`                                                            AS `solution`,
    `bugfree`.`bf_bug_info`.`duplicate_id`                                                        AS `duplicate_id`,
    `bugfree`.`bf_bug_info`.`product_id`                                                          AS `product_id`,
    `bugfree`.`bf_bug_info`.`reopen_count`                                                        AS `reopen_count`,
    `bugfree`.`bf_bug_info`.`priority`                                                            AS `priority`,
    `bugfree`.`bf_bug_info`.`severity`                                                            AS `severity`,
    `bugfree`.`bf_product`.`name`                                                                 AS `product_name`,
    concat_ws('/', `bugfree`.`bf_product`.`name`, `bugfree`.`bf_product_module`.`full_path_name`) AS `module_name`,
    `uc`.`realname`                                                                               AS `created_by_name`,
    `uu`.`realname`                                                                               AS `updated_by_name`,
    `ur`.`realname`                                                                               AS `resolved_by_name`,
    `uclo`.`realname`                                                                             AS `closed_by_name`,
    `ua`.`realname`                                                                               AS `assign_to_name`
  FROM (((((((`bugfree`.`bf_bug_info`
    LEFT JOIN `bugfree`.`bf_test_user` `uc` ON ((`bugfree`.`bf_bug_info`.`created_by` = `uc`.`id`))) LEFT JOIN
    `bugfree`.`bf_test_user` `uu` ON ((`bugfree`.`bf_bug_info`.`updated_by` = `uu`.`id`))) LEFT JOIN
    `bugfree`.`bf_test_user` `ur` ON ((`bugfree`.`bf_bug_info`.`resolved_by` = `ur`.`id`))) LEFT JOIN
    `bugfree`.`bf_test_user` `uclo` ON ((`bugfree`.`bf_bug_info`.`closed_by` = `uclo`.`id`))) LEFT JOIN
    `bugfree`.`bf_test_user` `ua` ON ((`bugfree`.`bf_bug_info`.`assign_to` = `ua`.`id`))) LEFT JOIN
    `bugfree`.`bf_product` ON ((`bugfree`.`bf_bug_info`.`product_id` = `bugfree`.`bf_product`.`id`))) LEFT JOIN
    `bugfree`.`bf_product_module`
      ON ((`bugfree`.`bf_bug_info`.`productmodule_id` = `bugfree`.`bf_product_module`.`id`)));
