	
	var USERNAME_LENGTH = 3;
	var USERNO_LENGTH = 3;
	
	$(function(){
		
		/** 用户分组 **/
		GroupList();
		
		/** 验证编号 **/
		$("input[name=userno]").blur(function(){

			//特殊
			/**
			var uu_userno = $("#userno").val();
			var uu_userno_len = uu_userno.length;
			if(uu_userno_len!=13 && uu_userno_len!=15 && uu_userno_len!=18){
				$("#span_userno").css("color","#ff0000");
				$("#span_userno").html("个人编号必须是13位，15位或者18位。");
				return false;
			}
			**/

			var this_val = $(this).val();
			if(this_val==null || ""==this_val){
				$("#span_userno").html("");
			}else{
				if(this_val.length<=USERNO_LENGTH){
					$("#span_userno").attr("style","color:#ff0000");
					$("#span_userno").html("编号输入长度必须大于"+USERNO_LENGTH);
					return;
				}
				$.ajax({
				   type: "POST",
				   url: "ajax.do?action=checkUser",
				   data: {val:$(this).val(),t:rnd(),cw:"userno"},
				   success: function(msg){
				     if("1"==msg || 1==msg){
					 	$("#span_userno").attr("style","color:#ff0000");
					 	$("#span_userno").html("编号["+this_val+"]已经存在");
					 }else{
					 	$("#span_userno").attr("style","color:#00ff00");
					 	$("#span_userno").html("编号["+this_val+"]可以使用");
					 }
				   }
				}); 
			}
		});
		
		
		/** 验证用户名 **/
		$("input[name=username]").blur(function(){
			var this_val = $(this).val();
			if(this_val==null || ""==this_val){
				$("#span_username").html("");
			}else{
				if(this_val.length<=USERNAME_LENGTH){
					$("#span_username").attr("style","color:#ff0000");
					$("#span_username").html("用户名输入长度必须大于"+USERNAME_LENGTH);
					return;
				}
				
				$.ajax({
				   type: "POST",
				   url: "ajax.do?action=checkUser",
				   data: {val:$(this).val(),t:rnd(),cw:"username"},
				   success: function(msg){
				     if("1"==msg || 1==msg){
					 	$("#span_username").attr("style","color:#ff0000");
					 	$("#span_username").html("用户名["+this_val+"]已经存在");
					 }else{
					 	$("#span_username").attr("style","color:#00ff00");
					 	$("#span_username").html("用户名["+this_val+"]可以使用");
					 }
				   }
				}); 
			}
			
		});
		
		
		/** 提交 **/
		$("#btnsubmit").click(function(){
			if(FormValidator()){
				Register();
			}
		});
		
		
	});
	
	
	
	/** 注册 **/
	function Register(){
		
		var userno = encodeURI(encodeURI($("#userno").val()));
		var username = encodeURI(encodeURI($("#username").val()));
		var userpass = $("#userpass").val();
		var realname = encodeURI(encodeURI($("#realname").val()));
		var email = $("#email").val();
		var mobi = $("#mobi").val();
		var gid = $("#gid").val();
		
		//alert(userno+","+username+","+userpass+","+realname+","+email+","+mobi+","+gid);
		
		$.ajax({
			type: "POST",
			url: "ajax.do?action=register",
			data: "username="+username+"&userpass="+userpass+"&userno="+userno+"&realname="+realname+"&email="+email+"&mobi="+mobi+"&gid="+gid+"&t="+rnd(),
			//data: {action:"register",username:username,userpass:userpass,userno:userno,realname:realname,email:email,mobi:mobi,gid:gid,t:rnd()},
			success: function(msg){
				if("1"==msg || 1==msg){
					alert("注册成功，请登陆");
				}else if("9"==msg || 9==msg){
					alert("注册失败，用户名已经存在。");
					return false;
				}else if("8"==msg || 8==msg){
					alert("注册失败，编号已经存在。");
					return false;
				}else if("99"==msg || 99==msg){
					alert("已经达到该版本的用户最大限制数，请联系管理员。");
					return false;
				}else{
					alert("注册失败，请联系管理员。"+msg);
					return false;
				}
				top.location.href = "login.jsp";
			}
		});
		
	}
	
	
	
	
	/** 获取用户分组 **/
	function GroupList(){
		$.getJSON("ajax.do?action=getUserGroups", {t:rnd()}, function(data){
			var html = "";
			for(var i=0;i<data.datalist.length;i++){
				var gname = "" + data.datalist[i].GROUPNAME;
				var id = data.datalist[i].ID;
				html += "<option value='"+id+"'>"+gname+"</option>";
			}
			$("#gid").html(html);
		});
	}
	
	
	
	
	/** 表单校验 **/
	function FormValidator(){
		$("#span_username").html("");
		$("#span_userno").html("");
		$("#span_realname").html("");
		$("#span_gid").html("");
		$("#span_userpass").html("");
		$("#span_userpass2").html("");
		
		if(IsNull($("#username").val())){
			$("#span_username").css("color","#ff0000");
			$("#span_username").html("用户名不能为空");
		}
		if(IsNull($("#userno").val())){
			$("#span_userno").css("color","#ff0000");
			$("#span_userno").html("个人编号不能为空");
		}
		if(IsNull($("#gid").val())){
			$("#span_gid").css("color","#ff0000");
			$("#span_gid").html("所属分组不能为空");
		}
		if(IsNull($("#realname").val())){
			$("#span_realname").css("color","#ff0000");
			$("#span_realname").html("真实姓名不能为空");
		}
		if(IsNull($("#userpass").val())){
			$("#span_userpass").css("color","#ff0000");
			$("#span_userpass").html("密码不能为空");
		}
		if($("#userpass2").val()!=$("#userpass").val()){
			$("#span_userpass2").css("color","#ff0000");
			$("#span_userpass2").html("确认密码不匹配");
		}
		
		if(IsNull($("#username").val())){
			return false;
		}
		if(IsNull($("#userno").val())){
			return false;
		}
		if(IsNull($("#gid").val())){
			return false;
		}
		if(IsNull($("#realname").val())){
			return false;
		}
		if(IsNull($("#userpass").val())){
			return false;
		}
		if($("#userpass2").val()!=$("#userpass").val()){
			return false;
		}
		

		//特殊
		/**
		var uu_userno = $("#userno").val();
		var uu_userno_len = uu_userno.length;
		if(uu_userno_len!=13 && uu_userno_len!=15 && uu_userno_len!=18){
			$("#span_userno").css("color","#ff0000");
			$("#span_userno").html("个人编号必须是13位，15位或者18位。");
			return false;
		}
		**/

		return true;
	}
	
	
	
	
	
	/** 空值检查 **/
	function IsNull(s){
		if(s==null || s==""){
			return true;
		}else{
			return false;
		}
	}
	
	
	/** EMAIL检查 **/
	function isEmail(str){
		res = /^[0-9a-zA-Z_\-\.]+@[0-9a-zA-Z_\-]+(\.[0-9a-zA-Z_\-]+)*$/;
		var re = new RegExp(res);
		return !(str.match(re) == null);
	}

	
