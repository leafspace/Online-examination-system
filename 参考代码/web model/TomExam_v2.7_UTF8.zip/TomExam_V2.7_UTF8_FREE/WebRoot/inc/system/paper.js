
var myDate = new Date();
var month = myDate.getMonth() + 1;
var smonth = ""+month;
if(month<10) smonth = "0" + month;

var sdate = "" + myDate.getFullYear() + "/" + smonth + "/" + myDate.getDate() + " 12:00";


$(function(){
	
	var qs = new queryStr();
	if(qs.action=="load"){
		//绘制表单
		$("select[name=status]").val(_status);
		$("input[name=starttime]").val(_starttime);
		$("input[name=endtime]").val(_endtime);
		$("input[name=paper_minute]").val(_paper_minute);
		$("input[name=show_score]").val(_show_score);
		$("input[name=qorder]").val(_qorder.split(""));
		$("input[name=groupids]").val(_usergroupids.split("#"));
		status_change($("select[name=status]"));
		
	}else if(qs.action=="add" || qs.action=="addrand"){//加载_与随机试卷设置
		$("#starttime").val(sdate);
		$("#endtime").val(sdate);
	}
	
});


function checkExamOutOfTime(){
	var user_val = $("#paper_minute").val();
	var count_val = get_max_paper_time();
	if(user_val>count_val){
		alert("设定的考试时长【"+user_val+"分钟】超出了考试的时间区间。");
		return true;
	}
	return false;
}


//计算考试时间
count_paper_minute = function(){
	var startDate= new Date($("#starttime").val()); 
	var endDate= new Date($("#endtime").val()); 
	var df=(endDate.getTime()-startDate.getTime());

	var int_hours = Math.floor(df/60000);
	//$("#paper_minute").val(int_hours);
	
}


function get_max_paper_time(){
	var int_minutes = 0;
	try{
		var startDate= new Date($("#starttime").val()); 
		var endDate= new Date($("#endtime").val()); 
		var df=(endDate.getTime()-startDate.getTime());
		int_minutes = Math.floor(df/60000);
	}catch(e){}
	return int_minutes;
}



function status_change(obj){
	var v = eval($(obj).val());
	if(v==1){
		$("#status_remark").html("<font color='green'>学生可以作答</font>");
	}else{
		$("#status_remark").html("<font color='red'>学生不能作答</font>");
	}
}






