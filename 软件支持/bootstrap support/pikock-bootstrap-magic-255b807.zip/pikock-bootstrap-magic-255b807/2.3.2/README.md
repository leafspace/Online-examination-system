Bootstrap magic
==============

Bootstrap themes generator made with AngularJS

[Try it out!](http://pikock.github.com/bootstrap-magic/)


#### Build on Angular-seed

For more information about [Angular-seed](https://github.com/angular/angular-seed/) Angular-seed please check out https://github.com/angular/angular-seed/


## Contact

For more information on [Pikock](http://www.pikock.com/)  please check out http://www.pikock.com/
For more information on [Autre planete](http://www.autreplanete.com/)  please check out http://www.autreplanete.com/
For more information on [AngularJS](http://angularjs.org/)  please check out http://angularjs.org/
For more information on [Twitter Bootstrap](http://twitter.github.com/bootstrap/)  please check out http://twitter.github.com/bootstrap/


